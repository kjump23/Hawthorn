//
//  ViewController.m
//  Publisher
//
//  Copyright © 2013-2017 TIBCO Software. All rights reserved.
//

#import "ViewController.h"
#import "AppDelegate.h"

#import <eFTL/eFTL.h>

// Set the following two variables to your
// TIBCO Cloud Messaging URL and authentication key.
//
static NSString *const EFTL_URL = @"TIBCO-CLOUD-MESSAGING-URL";
static NSString *const EFTL_KEY = @"TIBCO-CLOUD-MESSAGING-KEY";

@interface ViewController () <eFTLConnectionListener, eFTLCompletionListener>

@property eFTLConnection *connection;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.

    NSLog(@"%@", [eFTL version]);

    // Close the connection to TIBCO Cloud Messaging when the application
    // moves into the background. 
    //
    // Reconnect to TIBCO Cloud Messaging when the application moves into 
    // the foreground.
    //
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(reconnect)
                                                 name:UIApplicationDidBecomeActiveNotification
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(disconnect)
                                                 name:UIApplicationDidEnterBackgroundNotification
                                               object:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)connect {
    NSDictionary *props = @{
                            eFTLPropertyClientId: [[UIDevice currentDevice] name],
                            eFTLPropertyPassword: EFTL_KEY
                            };
    
    // Start a connection to TIBCO Cloud Messaging.
    //
    // connectionDidConnect: is invoked when successfully connected.
    //
    // connection:didDisconnectWithCode:reason is invoked when the
    // connection fails or becomes disconnected.
    //
    [eFTL connect:EFTL_URL properties:props listener:self];
}

- (void)reconnect {
    // Asynchronously reconnect to TIBCO Cloud Messaging.
    //
    if (self.connection != nil) {
        [self.connection reconnectWithProperties:nil];
    }
}

- (void)disconnect {
    // Disconnect from TIBCO Cloud Messaging.
    //
    [self.connection disconnect];
}

- (void)publish {
    // Create a message and populate its contents.
    //
    // Message fields can be of type string, long,
    // double, date, and message, along with arrays
    // of each of the types.
    //
    // Subscribers will create matchers that match
    // on one or more of the message fields. Only 
    // string and long fields are supported by 
    // matchers.
    //
    eFTLMessage *message = [eFTLMessage message];
    
    [message setField:@"stock" asString:@"ibm"];
    [message setField:@"price" asLong:[NSNumber numberWithLong:150]];
    [message setField:@"time" asDate:[NSDate date]];
    
    // Asynchronously publish the message to TIBCO Cloud Messaging.
    //
    // messageDidComplete: is invoked when the publish has been
    // acknowledged.
    //
    // message:didFailWithCode:reason: is invoked when the publish
    // fails.
    //
    [self.connection publishMessage:message listener:self];
}

- (IBAction)buttonPressed:(id)sender {
    // If not yet connected, start the connection to TIBCO
    // Cloud Messaging. Once connected a message will be
    // published. Otherwise, publish a message.
    //
    if (self.connection == nil) {
        [self connect];
    } else {
        [self publish];
    }
}

// Invoked when a connection to TIBCO Cloud Messaging is successful.
- (void)connectionDidConnect:(eFTLConnection *)connection {
    NSLog(@"Connected to TIBCO Cloud Messaging");
    self.connection = connection;
    [self publish];
}

// Invoked when reconnected to TIBCO Cloud Messaging.
- (void)connectionDidReconnect:(eFTLConnection *)connection {
    NSLog(@"Reconnected to TIBCO Cloud Messaging");
}

// Invoked when a connection to TIBCO Cloud Messaing is unsuccessful or lost.
- (void)connection:(eFTLConnection *)connection didDisconnectWithCode:(NSInteger)code reason:(NSString *)reason {
    NSLog(@"Disconnected from TIBCO Cloud Messaging: %@", (reason == nil ? @"entered background" : reason));
}

// Invoked when TIBCO Cloud Messaging responds with an error.
- (void)connection:(eFTLConnection *)connection didFailWithCode:(NSInteger)code reason:(NSString *)reason {
    NSLog(@"Error from TIBCO Cloud Messaging: %@", reason);
}

// Invoked when the message was successfully published.
- (void)messageDidComplete:(eFTLMessage *)message {
    NSLog(@"Published message: %@", message);
}

// Invoked when the message was unsuccessfully published.
- (void)message:(eFTLMessage *)message didFailWithCode:(NSInteger)code reason:(NSString *)reason {
    NSLog(@"Publish failed: %@", reason);
}

@end
