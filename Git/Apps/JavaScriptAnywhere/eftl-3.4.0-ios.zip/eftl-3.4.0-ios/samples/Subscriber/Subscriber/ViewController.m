//
//  ViewController.m
//  Subscriber
//
//  Copyright © 2013-2017 TIBCO Software. All rights reserved.
//

#import "ViewController.h"
#import "AppDelegate.h"

#import <eFTL/eFTL.h>

// Set the following two variables to your
// TIBCO Cloud Messaging URL and authentication key.
//
static NSString *const EFTL_URL = @"TIBCO-CLOUD-MESSAGING-URL";
static NSString *const EFTL_KEY = @"TIBCO-CLOUD-MESSAGING-KEY";

@interface ViewController () <eFTLConnectionListener, eFTLSubscriptionListener>

@property eFTLConnection *connection;
@property BOOL subscribed;
@property (weak, nonatomic) IBOutlet UIButton *subscribeButton;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    NSLog(@"%@", [eFTL version]);
    
    // Close the connection to TIBCO Cloud Messaging when the application
    // moves into the background. 
    //
    // Reconnect to TIBCO Cloud Messaging when the application moves into 
    // the foreground.
    //
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(reconnect)
                                                 name:UIApplicationDidBecomeActiveNotification
                                               object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(disconnect)
                                                 name:UIApplicationDidEnterBackgroundNotification
                                               object:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)connect {
    NSDictionary *props;
    
    props = @{
              eFTLPropertyClientId: [[UIDevice currentDevice] name],
              eFTLPropertyPassword: EFTL_KEY
              };

    // Start a connection to TIBCO Cloud Messaging.
    //
    // connectionDidConnect: is invoked when successfully connected.
    //
    // connection:didDisconnectWithCode:reason is invoked when the
    // connection fails or becomes disconnected.
    //
    [eFTL connect:EFTL_URL properties:props listener:self];
}

- (void)reconnect {
    // Asynchronously reconnect to TIBCO Cloud Messaging.
    //
    [self.connection reconnectWithProperties:nil];
}

- (void)disconnect {
    // Disconnect from TIBCO Cloud Messaging.
    //
    [self.connection disconnect];
}

- (void)subscribe {
    // Asynchronously subscribe to messages.
    //
    // A subscription receives only those messages whose
    // fields match the subscription's matcher string.
    // A subscription can only match on string and
    // integer fields.
    //
    // To match all messages use the empty matcher "{}".
    //
    // This subscription matches messages containing a string
    // field with name "stock" and value "ibm".
    //
    // The durable name "stock" is being used for this 
    // subscription.
    //
    // didReceiveMessages: is invoked when messages matching
    // the subscription are received.
    //
    // subscriptionDidSubscribe: is invoked when the subscription
    // is successful.
    //
    // subscription:didFailWithCode:reason: is invoked when the
    // subscription fails.
    //
    [self.connection subscribeWithMatcher:@"{\"stock\":\"ibm\"}" durable:@"stock" listener:self];
}

- (void)unsubscribe {
    // Asynchronously unsubscribe from all subscriptions.
    //
    [self.connection unsubscribeAll];
    [self.subscribeButton setTitle:@"Subscribe" forState:UIControlStateNormal];
    NSLog(@"Unsubscribed");
    self.subscribed = NO;
}

- (IBAction)buttonPressed:(id)sender {
    // If not yet connected, start the connection to TIBCO
    // Cloud Messaging. Once connected, the subscription will
    // be made. Otherwise, either subscribe or unsubscribe
    // depending on the current state.
    //
    if (self.connection == nil) {
        [self connect];
    } else if (self.subscribed){
        [self unsubscribe];
    } else {
        [self subscribe];
    }
}

// Invoked when a connection to TIBCO Cloud Messaging is successful.
- (void)connectionDidConnect:(eFTLConnection *)connection {
    NSLog(@"Connected to TIBCO Cloud Messaging");
    self.connection = connection;
    [self subscribe];
}

// Invoked when reconnected to TIBCO Cloud Messaging.
- (void)connectionDidReconnect:(eFTLConnection *)connection {
    NSLog(@"Reconnected to TIBCO Cloud Messaing");
}

// Invoked when a connection to TIBCO Cloud Messaing is unsuccessful or lost.
- (void)connection:(eFTLConnection *)connection didDisconnectWithCode:(NSInteger)code reason:(NSString *)reason {
    NSLog(@"Disconnected from TIBCO Cloud Messaging: %@", (reason == nil ? @"entered background" : reason));
}

// Invoked when TIBCO Cloud Messaing responds with an error.
- (void)connection:(eFTLConnection *)connection didFailWithCode:(NSInteger)code reason:(NSString *)reason {
    NSLog(@"Error from TIBCO Cloud Messaing: %@", reason);
}

// Invoked when the subscription receives messages.
- (void)didReceiveMessages:(NSArray *)messages {
    for (id message in messages) {
        NSLog(@"Received message: %@", message);
    }
}

// Invoked when the subscription is successful.
- (void)subscriptionDidSubscribe:(NSString *)subscription {
    NSLog(@"Subscribed");
    [self.subscribeButton setTitle:@"Unsubscribe" forState:UIControlStateNormal];
    self.subscribed = YES;
}

// Invoked when the subscription is unsuccessful.
- (void)subscription:(NSString *)subscription didFailWithCode:(NSInteger)code reason:(NSString *)reason {
    NSLog(@"Subscription failed: %@", reason);
}

@end
