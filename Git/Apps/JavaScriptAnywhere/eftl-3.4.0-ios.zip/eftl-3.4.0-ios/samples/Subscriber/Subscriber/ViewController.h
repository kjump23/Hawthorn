//
//  ViewController.h
//  Subscriber
//
//  Copyright © 2013-2017 TIBCO Software. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

