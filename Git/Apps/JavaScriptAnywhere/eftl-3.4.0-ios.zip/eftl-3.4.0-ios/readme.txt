/*
 * Copyright (c) 2013-2017 TIBCO Software Inc.
 * All Rights Reserved.
 * For more information, please contact:
 * TIBCO Software Inc., Palo Alto, California, USA
 */

This directory contains the iOS client for TIBCO eFTL 3.4.0
and Object-C examples.

The iOS client framework is located at:

     Library/Frameworks/eFTL.framework

Samples located in this directory are simple examples of
basic TIBCO eFTL functionality.


Running the eFTL iOS Sample Applications
----------------------------------------

The iOS sample applications demonstrate how to connect to TIBCO
Cloud Messaging, subscribe to messages, and publish messages.

Steps required to build the eFTL iOS sample applications:

  1. Open the eFTL iOS sample Xcode project.

  2. Add the eFTL Objective-C framework to the project by either
     dragging the eFTL framework  bundle from a Finder window into
     the project in the project navigator, or by choosing the menu
     options File > Add Files to "<App_Name>" and selecting the
     eFTL framework bundle.

  3. Replace the placeholder URL and authentication key

         TIBCO-CLOUD-MESSAGING-URL
         TIBCO-CLOUD-MESSAGING-KEY

     in ViewController.m with the URL and authentication key
     provided by TIBCO Cloud Messaging.

  4. Build and run the eFTL iOS sample application.


Creating a new eFTL iOS Application
-----------------------------------

When creating a new eFTL iOS application, along with the inclusion of the
eFTL framework bundle, the following steps are required to set up the proper 
dependencies and configuration for your project. These steps are already
a part of the eFTL iOS sample Xcode projects: 

  1. Add the required built-in frameworks to the project.

      a. In the project navigator, select the project.

      b. Click "Build Phases" at the top of the project editor.

      c. Open the "Link Binary With Libraries" section.

      d. Click the add (+) button to add a library or framework.

      e. Enter the following library and frameworks in the search field, 
         select and "Add".

            libicucore.tbd
            CFNetwork.framework
            Security.framework

  2. Add the -ObjC value to the "Other Linker Flags" build setting.

      a. In the project navigator, select the target.

      b. Click the "Build Setting" tab and scroll down to the "Linking"
         section.

      c. In "Other Linker Flags" add the value "-ObjC".

